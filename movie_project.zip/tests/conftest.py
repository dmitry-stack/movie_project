import pytest
from app import create_app
from app.extensions import db
from app.config import TestConfig


@pytest.fixture
def app():
    """Create a new app instance for each test."""
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    """Create a test client for the app."""
    return app.test_client()
