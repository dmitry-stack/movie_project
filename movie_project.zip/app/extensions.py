from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf import CSRFProtect

# ======== EXTENSIONS =========
db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()